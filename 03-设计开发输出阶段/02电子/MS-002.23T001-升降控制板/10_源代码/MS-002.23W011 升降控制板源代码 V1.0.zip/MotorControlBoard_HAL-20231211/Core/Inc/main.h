/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
//����һЩ���õ��������Ͷ̹ؼ��� 
typedef int32_t  s32;
typedef int16_t s16;
typedef int8_t  s8;

typedef const int32_t sc32;  
typedef const int16_t sc16;  
typedef const int8_t sc8;  

typedef __IO int32_t  vs32;
typedef __IO int16_t  vs16;
typedef __IO int8_t   vs8;

typedef __I int32_t vsc32;  
typedef __I int16_t vsc16; 
typedef __I int8_t vsc8;   

typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;

typedef const uint32_t uc32;  
typedef const uint16_t uc16;  
typedef const uint8_t uc8; 

typedef __IO uint32_t  vu32;
typedef __IO uint16_t vu16;
typedef __IO uint8_t  vu8;

typedef __I uint32_t vuc32;  
typedef __I uint16_t vuc16; 
typedef __I uint8_t vuc8;  	
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_RUN_Pin GPIO_PIN_13
#define LED_RUN_GPIO_Port GPIOC
#define SIG_TO_UR_Pin GPIO_PIN_14
#define SIG_TO_UR_GPIO_Port GPIOC
#define SIG_FROM_UR_Pin GPIO_PIN_15
#define SIG_FROM_UR_GPIO_Port GPIOC
#define OE_Pin GPIO_PIN_3
#define OE_GPIO_Port GPIOC
#define M1_A_Pin GPIO_PIN_0
#define M1_A_GPIO_Port GPIOA
#define M1_B_Pin GPIO_PIN_1
#define M1_B_GPIO_Port GPIOA
#define M2_A_Pin GPIO_PIN_6
#define M2_A_GPIO_Port GPIOA
#define M2_B_Pin GPIO_PIN_7
#define M2_B_GPIO_Port GPIOA
#define M_AD4_Pin GPIO_PIN_4
#define M_AD4_GPIO_Port GPIOC
#define M_AD3_Pin GPIO_PIN_5
#define M_AD3_GPIO_Port GPIOC
#define M_AD2_Pin GPIO_PIN_0
#define M_AD2_GPIO_Port GPIOB
#define M_AD1_Pin GPIO_PIN_1
#define M_AD1_GPIO_Port GPIOB
#define M_B4_Pin GPIO_PIN_12
#define M_B4_GPIO_Port GPIOB
#define M_F4_Pin GPIO_PIN_13
#define M_F4_GPIO_Port GPIOB
#define M_B3_Pin GPIO_PIN_14
#define M_B3_GPIO_Port GPIOB
#define M_F3_Pin GPIO_PIN_15
#define M_F3_GPIO_Port GPIOB
#define M_B2_Pin GPIO_PIN_6
#define M_B2_GPIO_Port GPIOC
#define M_F2_Pin GPIO_PIN_7
#define M_F2_GPIO_Port GPIOC
#define M_B1_Pin GPIO_PIN_8
#define M_B1_GPIO_Port GPIOC
#define M_F1_Pin GPIO_PIN_9
#define M_F1_GPIO_Port GPIOC
#define SWDIO_Pin GPIO_PIN_13
#define SWDIO_GPIO_Port GPIOA
#define SWCLK_Pin GPIO_PIN_14
#define SWCLK_GPIO_Port GPIOA
#define M3_A_Pin GPIO_PIN_15
#define M3_A_GPIO_Port GPIOA
#define IIC_SCL_Pin GPIO_PIN_10
#define IIC_SCL_GPIO_Port GPIOC
#define IIC_SDA_Pin GPIO_PIN_11
#define IIC_SDA_GPIO_Port GPIOC
#define _3D_INT_Pin GPIO_PIN_12
#define _3D_INT_GPIO_Port GPIOC
#define M3_B_Pin GPIO_PIN_3
#define M3_B_GPIO_Port GPIOB
#define TC_LED_DOWN_Pin GPIO_PIN_4
#define TC_LED_DOWN_GPIO_Port GPIOB
#define TC_DOWN_Pin GPIO_PIN_5
#define TC_DOWN_GPIO_Port GPIOB
#define M4_A_Pin GPIO_PIN_6
#define M4_A_GPIO_Port GPIOB
#define M4_B_Pin GPIO_PIN_7
#define M4_B_GPIO_Port GPIOB
#define TC_LED_UP_Pin GPIO_PIN_8
#define TC_LED_UP_GPIO_Port GPIOB
#define TC_UP_Pin GPIO_PIN_9
#define TC_UP_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
//void printf_DMA(char *fmt,...); 
//#define printf printf_DMA
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
